<?php
/**
 * repaynotify.php
 * Easypay聚合支付系统
 * =========================================================
 * Copy right 2015-2025 Easypay, 保留所有权利。
 * ----------------------------------------------
 * 官方网址: http://www.0533hf.com
 *
 * 请尊重开发人员劳动成果，严禁使用本系统转卖、销售或二次开发后转卖、销售等商业行为。
 * 任何企业和个人不允许对程序代码以任何形式任何目的再发布。
 * =========================================================
 * @author : 366131726@qq.com
 * @date : 2019-05-14
 */


require 'config.php';

file_put_contents('./repay.txt',file_get_contents('php://input'));

$flag = verify($_POST,$md5Key,$publicKey);

if($flag){

    //处理逻辑
    exit('success');
}

exit('sign error');