<?php
/**
 * repay.php
 * Easypay聚合支付系统
 * =========================================================
 * Copy right 2015-2025 Easypay, 保留所有权利。
 * ----------------------------------------------
 * 官方网址: http://www.0533hf.com
 *
 * 请尊重开发人员劳动成果，严禁使用本系统转卖、销售或二次开发后转卖、销售等商业行为。
 * 任何企业和个人不允许对程序代码以任何形式任何目的再发布。
 * =========================================================
 * @author : 366131726@qq.com
 * @date : 2019-05-14
 */

require 'config.php';
//请求地址
$api = $gateway.'/pay/repay';

//请求格式
$data = [
    'merId' => $merId,    //商户号
    'orderId' => time(),     //订单号，值允许英文数字
    'money'=>200,           //申请代付金额
    'name'=>'张三',
    'ka'=>'62284802861395788605',
    'bank'=>'农业银行',
    'notifyUrl'=>'http://pay.0533hf.com/demo/repaynotify.php',
    'attach'=>'1234',
    'nonceStr' => Random::alnum('32')   //随机字符串不超过32位
];
//私钥签名
$data['sign'] = sign($data,$md5Key,$privateKey);

$resp = Http::post($api, $data);

var_dump($resp);